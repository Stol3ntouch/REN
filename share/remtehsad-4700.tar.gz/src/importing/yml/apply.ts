import { clearCategoryImageCache } from '@/domain/catalog/category-images';
import { safeFetchImage } from '@/media/safe-fetch';
import { storeImage, type StoredImage } from '@/media/store-image';
import { withTransaction, type Db } from '@/server/db/connection';
import { attributesRepo } from '@/server/db/repositories/attributes';
import { brandsRepo } from '@/server/db/repositories/brands';
import { categoriesRepo } from '@/server/db/repositories/categories';
import { imagesRepo } from '@/server/db/repositories/images';
import { importRunsRepo } from '@/server/db/repositories/import-runs';
import { productsRepo, type ProductPatch } from '@/server/db/repositories/products';
import { categorySlugBase, diffProduct, productSlugBase } from './plan';
import { slugify, uniqueSlug } from './slug';
import { YML_SOURCE, type ImportPlan, type ImportReport, type RowError } from './types';

export type ImageIngestOptions = {
  /** Скачивание; по умолчанию safeFetchImage (allowlist, SSRF-защита). */
  fetchImage?: (url: string) => Promise<{ bytes: Uint8Array }>;
  /** Сохранение; по умолчанию storeImage (сигнатура, перекодирование, варианты). */
  storeImage?: (bytes: Uint8Array) => Promise<StoredImage>;
  concurrency?: number;
};

export type ApplyOptions = {
  now?: Date;
  actorId?: number | null;
  /** Скачивать фото (по умолчанию нет: хранится только url_source). */
  images?: false | ImageIngestOptions;
  /** Мастер: запись журнала уже создана — обновить её, а не вставлять новую. */
  runId?: number;
  /** create_only — существующие товары пропускаются. */
  mode?: 'create_only' | 'update';
  /** Перезаписывать поля из locked_fields. */
  overrideLocked?: boolean;
  /** true (по умолчанию, CLI) — одна транзакция; false — категории отдельно, товары пакетами по 500 с передышкой между ними. */
  atomic?: boolean;
  /** Сколько товаров обработано (после каждого пакета). */
  onProgress?: (processed: number) => void;
};

/**
 * Бренд товара — только из данных файла (<vendor>). Бренд ищется по названию без учёта регистра, иначе создаётся (source=yml).
 * Бренд, назначенный администратором вручную (не из импорта), не перезаписывается; нет <vendor> — ничего не меняется.
 */
function bindBrand(db: Db, productId: number, vendor: string | null | undefined, takenSlugs: Set<string>, nowIso: string, lockedFields: readonly string[] = []): void {
  if (lockedFields.includes('brand')) return; // бренд правили вручную (C04)
  const name = (vendor ?? '').trim();
  if (name === '') return;
  let brand = brandsRepo.findByName(db, name);
  if (!brand) {
    const key = name.toLowerCase();
    const slug = uniqueSlug(slugify(name) || 'brand', slugify(name) || key, takenSlugs);
    const id = brandsRepo.insert(db, { name, slug, description: null, siteUrl: null, published: true, sort: 0, seoTitle: null, seoDescription: null, source: YML_SOURCE, externalId: key }, nowIso);
    brand = brandsRepo.findById(db, id);
  }
  if (!brand) return;
  const current = brandsRepo.getProductBrandId(db, productId);
  if (current === brand.id) return;
  if (current != null && brandsRepo.findById(db, current)?.source !== YML_SOURCE) return;
  brandsRepo.setProductBrand(db, productId, brand.id);
}

function errorText(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

/**
 * Применяет план к БД идемпотентно по (source='yml', external_id). Товары, которых нет в файле, не удаляются;
 * поля из locked_fields не перезаписываются; сбой одной строки откатывает только её и попадает в отчёт.
 * Скачивание фото (если включено) идёт после записи и не блокирует импорт.
 */
export async function applyImport(plan: ImportPlan, db: Db, opts: ApplyOptions = {}): Promise<ImportReport> {
  const startedAt = (opts.now ?? new Date()).toISOString();
  const nowIso = startedAt;
  const errors: RowError[] = [...plan.errors];
  const report: ImportReport = {
    runId: 0,
    fileName: plan.fileName,
    startedAt,
    finishedAt: startedAt,
    categories: { created: 0, updated: 0, unchanged: 0 },
    products: { created: 0, updated: 0, unchanged: 0, lockedFieldsSkipped: 0 },
    images: { enabled: !!opts.images, stored: 0, failed: 0, pending: 0 },
    errors,
    notes: [],
  };
  const touchedProducts = new Map<number, string>(); // id → externalId

  const atomic = opts.atomic !== false;
  const takenCategorySlugs = categoriesRepo.allSlugs(db);
  const idByExternal = new Map<string, number>();
  const created = new Set<string>();
  const touchedCategories = new Set<string>();
  const categoriesPhase = () => {
    // --- категории: сначала создаём/переименовываем, затем расставляем родителей (порядок в файле не важен)
    for (const c of categoriesRepo.listAll(db)) if (c.source === YML_SOURCE) idByExternal.set(c.externalId, c.id);

    for (const pc of plan.categories) {
      const cat = pc.data;
      try {
        withTransaction(db, () => {
          const existing = categoriesRepo.findByExternalId(db, YML_SOURCE, cat.externalId);
          if (!existing) {
            const slug = takenCategorySlugs.has(pc.slug) ? uniqueSlug(categorySlugBase(cat), cat.externalId, takenCategorySlugs) : (takenCategorySlugs.add(pc.slug), pc.slug);
            idByExternal.set(cat.externalId, categoriesRepo.insert(db, { source: YML_SOURCE, externalId: cat.externalId, parentId: null, name: cat.name, slug, sort: cat.position }));
            created.add(cat.externalId);
          } else if (existing.name !== cat.name) {
            categoriesRepo.update(db, existing.id, { name: cat.name });
            touchedCategories.add(cat.externalId);
          }
        });
      } catch (e) {
        errors.push({ kind: 'category', externalId: cat.externalId, position: cat.position, message: `Категория ${cat.externalId}: ${errorText(e)}` });
      }
    }
    for (const pc of plan.categories) {
      const cat = pc.data;
      const id = idByExternal.get(cat.externalId);
      if (id === undefined) continue;
      const parentId = cat.parentExternalId === null ? null : (idByExternal.get(cat.parentExternalId) ?? null);
      const current = categoriesRepo.listAll(db).find((c) => c.id === id)?.parentId ?? null;
      if (current !== parentId) {
        categoriesRepo.update(db, id, { parentId });
        touchedCategories.add(cat.externalId);
      }
      if (created.has(cat.externalId)) report.categories.created++;
      else if (touchedCategories.has(cat.externalId)) report.categories.updated++;
      else report.categories.unchanged++;
    }

    // скрытие категорий администратором (F6) наследуется: новая подкатегория или перенос под скрытого родителя скрывают её
    categoriesRepo.recomputeEffectiveHidden(db);

  };
  const takenProductSlugs = productsRepo.allSlugs(db);
  const takenBrandSlugs = brandsRepo.allSlugs(db);
  const productsPhase = (list: typeof plan.products) => {
    for (const pp of list) {
      const offer = pp.data;
      try {
        withTransaction(db, () => {
          const categoryId = idByExternal.get(offer.categoryExternalId);
          if (categoryId === undefined) throw new Error(`категория ${offer.categoryExternalId} не найдена`);
          const existing = productsRepo.findByExternalId(db, YML_SOURCE, offer.externalId);

          if (!existing) {
            const slug = takenProductSlugs.has(pp.slug) ? uniqueSlug(productSlugBase(offer), offer.externalId, takenProductSlugs) : (takenProductSlugs.add(pp.slug), pp.slug);
            const id = productsRepo.insert(db, {
              source: YML_SOURCE,
              externalId: offer.externalId,
              sku: offer.sku,
              name: offer.name,
              slug,
              description: offer.description,
              categoryId,
              priceKopecks: offer.priceKopecks,
              inStock: offer.inStock,
              now: nowIso,
            });
            attributesRepo.replaceForProduct(db, id, offer.attributes);
            imagesRepo.replaceForProduct(db, id, offer.pictures, offer.name);
            bindBrand(db, id, offer.vendor, takenBrandSlugs, nowIso);
            touchedProducts.set(id, offer.externalId);
            report.products.created++;
            return;
          }

          touchedProducts.set(existing.id, offer.externalId);
          bindBrand(db, existing.id, offer.vendor, takenBrandSlugs, nowIso, existing.lockedFields);
          // Решение принимается по текущему состоянию БД (план мог устареть) и актуальному locked_fields.
          if (opts.mode === 'create_only') {
            report.products.unchanged++;
            return;
          }
          const diff = diffProduct(db, existing, offer, { overrideLocked: opts.overrideLocked });
          report.products.lockedFieldsSkipped += diff.lockedSkipped.length;
          if (diff.changes.length === 0) {
            report.products.unchanged++;
            return;
          }
          const patch: ProductPatch = {};
          for (const f of diff.changes) {
            if (f === 'name') patch.name = offer.name;
            else if (f === 'sku') patch.sku = offer.sku;
            else if (f === 'description') patch.description = offer.description;
            else if (f === 'category') patch.categoryId = categoryId;
            else if (f === 'price') patch.priceKopecks = offer.priceKopecks;
            else if (f === 'in_stock') patch.inStock = offer.inStock;
          }
          productsRepo.update(db, existing.id, patch, nowIso);
          if (diff.changes.includes('attributes')) attributesRepo.replaceForProduct(db, existing.id, offer.attributes);
          if (diff.changes.includes('images')) imagesRepo.replaceForProduct(db, existing.id, offer.pictures, patch.name ?? existing.name);
          productsRepo.touch(db, existing.id, nowIso); // и когда менялись только характеристики или фото
          report.products.updated++;
        });
      } catch (e) {
        errors.push({ kind: 'offer', externalId: offer.externalId, position: offer.position, message: `Товар ${offer.externalId}: не записан — ${errorText(e)}` });
      }
    }
  };
  if (atomic) {
    withTransaction(db, () => {
      categoriesPhase();
      productsPhase(plan.products);
    });
    opts.onProgress?.(plan.products.length);
  } else {
    withTransaction(db, categoriesPhase);
    for (let i = 0; i < plan.products.length; i += 500) {
      const chunk = plan.products.slice(i, i + 500);
      try {
        withTransaction(db, () => productsPhase(chunk));
      } catch (e) {
        errors.push({ kind: 'offer', position: chunk[0]?.data.position, message: `Пакет товаров ${i + 1}–${i + chunk.length} откатан: ${errorText(e)}` });
      }
      opts.onProgress?.(Math.min(plan.products.length, i + chunk.length));
      await new Promise((r) => setImmediate(r));
    }
  }

  // --- фото: после записи, вне транзакции; сбои идут в отчёт и ничего не откатывают
  const productIds = [...touchedProducts.keys()];
  if (opts.images) await ingestImages(db, productIds, touchedProducts, opts.images, report);
  report.images.pending = imagesRepo.listPending(db, productIds).length;
  // Плитки категорий берут первое фото товара из кэша процесса: после импорта (новые ссылки, скачанные копии) он устарел.
  clearCategoryImageCache();

  report.finishedAt = (opts.now ?? new Date()).toISOString();
  const journal = {
    fileName: plan.fileName,
    mode: 'apply' as const,
    actorId: opts.actorId ?? null,
    startedAt: report.startedAt,
    finishedAt: report.finishedAt,
    categoriesCreated: report.categories.created,
    categoriesUpdated: report.categories.updated,
    productsCreated: report.products.created,
    productsUpdated: report.products.updated,
    productsUnchanged: report.products.unchanged,
    imagesStored: report.images.stored,
    imagesFailed: report.images.failed,
    errors,
    errorCount: errors.length,
  };
  if (opts.runId !== undefined) {
    importRunsRepo.update(db, opts.runId, { ...journal, status: 'done', progress: plan.products.length, rowsTotal: plan.products.length });
    report.runId = opts.runId;
  } else {
    report.runId = importRunsRepo.insert(db, { ...journal, format: 'yml' });
  }
  return report;
}

async function ingestImages(db: Db, productIds: number[], externalIds: Map<number, string>, o: ImageIngestOptions, report: ImportReport): Promise<void> {
  const fetchImage = o.fetchImage ?? ((url: string) => safeFetchImage(url));
  const store = o.storeImage ?? ((bytes: Uint8Array) => storeImage(bytes));
  const pending = imagesRepo.listPending(db, productIds);
  const byUrl = new Map<string, Promise<StoredImage>>(); // один URL у нескольких товаров — одна загрузка
  let next = 0;

  const worker = async () => {
    for (;;) {
      const row = pending[next++];
      if (!row) return;
      try {
        let job = byUrl.get(row.urlSource);
        if (!job) {
          job = fetchImage(row.urlSource).then((r) => store(r.bytes));
          byUrl.set(row.urlSource, job);
        }
        const stored = await job;
        imagesRepo.setStored(db, row.id, { path: stored.path, variants: stored.variants });
        report.images.stored++;
      } catch (e) {
        report.images.failed++;
        report.errors.push({ kind: 'image', externalId: externalIds.get(row.productId), message: `Фото ${row.urlSource}: ${errorText(e)}` });
      }
    }
  };
  const n = Math.max(1, Math.min(o.concurrency ?? 4, 16));
  await Promise.all(Array.from({ length: Math.min(n, pending.length) }, worker));
}
