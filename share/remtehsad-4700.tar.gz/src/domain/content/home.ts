import { getCategoryTree } from '@/domain/catalog/categories';
import { getPopularitySql } from '@/domain/catalog/popularity';
import { getCategoryImages } from '@/domain/catalog/category-images';
import { listCards } from '@/domain/catalog/store';
import type { CatalogImage, ProductCard } from '@/domain/catalog/types';
import { cardsByIds } from '@/domain/customers/cards';
import { getDb, type Db } from '@/server/db/connection';
import { homeProductsRepo } from '@/server/db/repositories/home-products';
import type { CompanyReviewRow } from '@/server/db/repositories/company-reviews';
import type { NewsRow } from '@/server/db/repositories/news';
import type { PageRow } from '@/server/db/repositories/pages';
import type { PromotionRow } from '@/server/db/repositories/promotions';
import type { ServiceRow } from '@/server/db/repositories/services';
import {
  getPageByKey,
  listBanners,
  listActivePromotions,
  listHeroSlides,
  listPublishedNews,
  listPublishedReviews,
  listPublishedServices,
  type BannerView,
  type HeroSlide,
  type WithImage,
} from './queries';
import { getSettings, getShopInfo, type ShopInfo } from './settings';

export const HOME_BLOCK_SIZE = 8;
export const HOME_CATEGORIES = 6;
/** «Новинка» — товар, впервые увиденный в каталоге не позже этого числа дней назад. */
export const NEW_PRODUCT_DAYS = 30;

export type HomeCategory = { id: number; slug: string; name: string; productCount: number; image: CatalogImage | null };

export const DEFAULT_HOME_H1 = 'РемТехСад — профессиональный подход к садовой технике: подберём новую, починим старую';

export type HomeData = {
  shop: ShopInfo;
  /** Редактируемые SEO-поля главной (настройки home_h1, home_title, home_description). */
  seo: { h1: string; title: string | null; description: string | null };
  /** Баннеры позиции home_hero (до трёх): слайдер главной. */
  slides: HeroSlide[];
  /** Баннеры позиции home_middle: полоса между блоками. */
  middleBanners: BannerView[];
  categories: HomeCategory[];
  newProducts: ProductCard[];
  popularProducts: ProductCard[];
  promoProducts: ProductCard[];
  /** Запасной блок: первые товары каталога по алфавиту; заполнен, только если нет ни хитов, ни акций, ни новинок. */
  catalogProducts: ProductCard[];
  promotions: WithImage<PromotionRow>[];
  services: WithImage<ServiceRow>[];
  reviews: CompanyReviewRow[];
  news: WithImage<NewsRow>[];
  about: PageRow | null;
};

type Opts = { db?: Db; now?: Date };

/**
 * Данные главной. Пустые блоки — пустые массивы (страница их не рисует). Ничего не выдумывается:
 *  - новые — товары, впервые увиденные за NEW_PRODUCT_DAYS дней, но не весь каталог сразу (первая загрузка ≠ «новинки»);
 *  - популярные — избранные админом (products.featured), иначе самые продаваемые; нет ни тех ни других — блока нет;
 *  - акционные — только с реальной скидочной ценой (discount < price).
 */
export async function getHomeData(opts: Opts = {}): Promise<HomeData> {
  const db = opts.db ?? getDb();
  const now = opts.now ?? new Date();
  const nowMs = now.getTime();

  // плитки главной: «Показывать на главной» (show_on_home) независимо от показа в каталоге; порядок — приоритет и позиция из админки
  const tree = await getCategoryTree({ db, all: true });
  const top = tree.filter((c) => c.showOnHome && c.productCount > 0).slice(0, HOME_CATEGORIES);
  // фото категории — фото первого товара её поддерева (общий помощник каталога, с кэшем)
  const images = getCategoryImages(top.map((c) => c.id), { db, now: nowMs });
  const categories: HomeCategory[] = top.map((c) => ({ id: c.id, slug: c.slug, name: c.name, productCount: c.productCount, image: images.get(c.id) ?? null }));

  const sinceIso = new Date(nowMs - NEW_PRODUCT_DAYS * 86_400_000).toISOString();
  const published = homeProductsRepo.countPublished(db);
  const newCount = homeProductsRepo.countNewSince(db, sinceIso);
  const newIds = newCount > 0 && newCount < published ? homeProductsRepo.newIds(db, sinceIso, HOME_BLOCK_SIZE) : [];

  let popularIds = homeProductsRepo.featuredIds(db, HOME_BLOCK_SIZE);
  if (popularIds.length === 0) {
    const sql = getPopularitySql(db);
    if (sql) popularIds = homeProductsRepo.topSoldIds(db, sql, HOME_BLOCK_SIZE);
  }

  const newProducts = cardsByIds(db, newIds);
  const popularProducts = cardsByIds(db, popularIds);
  const promoProducts = cardsByIds(db, homeProductsRepo.discountedIds(db, HOME_BLOCK_SIZE));
  const catalogProducts =
    newProducts.length + popularProducts.length + promoProducts.length === 0 ? listCards(db, { match: null, filters: {} }, 'name', HOME_BLOCK_SIZE, 0) : [];

  const settings = getSettings({ db });
  return {
    shop: getShopInfo({ db }),
    seo: {
      h1: settings.home_h1?.trim() || DEFAULT_HOME_H1,
      title: settings.home_title?.trim() || null,
      description: settings.home_description?.trim() || null,
    },
    slides: listHeroSlides({ db, now: nowMs }),
    middleBanners: listBanners('home_middle', { db, now: nowMs }),
    categories,
    newProducts,
    popularProducts,
    promoProducts,
    catalogProducts,
    promotions: listActivePromotions({ db, now: nowMs }),
    services: listPublishedServices({ db }),
    reviews: listPublishedReviews({ db, limit: 3 }),
    news: listPublishedNews({ db, limit: 3, now: nowMs }),
    about: getPageByKey('about', { db, now: nowMs }),
  };
}
